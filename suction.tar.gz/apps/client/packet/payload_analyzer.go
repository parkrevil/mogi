package packet

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"log"
	"os"
	"path/filepath"
	"sort"
	"time"
)

const (
	attackDataType      = 10308
	hpDataType          = 100178
	actionDataType      = 100041
	selfDamageDataType1 = 10701
	selfDamageDataType2 = 10719
	itemDataType1       = 100321
	itemDataType2       = 100322
)

const (
	dequeueInterval = 200 * time.Millisecond
)

var (
	startDelimiter        = []byte{0x68, 0x27, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
	endDelimiter          = []byte{0xe3, 0x27, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
	segmentMetadataLength = 9
)

var (
	payloadQueue     = make(chan Payload, 1000)
	payloadQueueDone = make(chan struct{})
)

type AnalyzedPayload struct {
	Type    int
	Content []byte
}

type Payload struct {
	Data      []byte
	Timestamp time.Time
}

func startPayloadQueueProcessor() {
	go func() {
		var queued []Payload
		ticker := time.NewTicker(dequeueInterval)
		defer ticker.Stop()

		for {
			select {
			case payload := <-payloadQueue:
				queued = append(queued, payload)

			case <-ticker.C:
				if len(queued) == 0 {
					continue
				}

				payloads := make([]Payload, len(queued))
				copy(payloads, queued)
				queued = queued[:0]

				sort.Slice(payloads, func(i, j int) bool {
					return payloads[i].Timestamp.Before(payloads[j].Timestamp)
				})

				analyzePayloads(payloads)

			case <-payloadQueueDone:
				return
			}
		}
	}()
}

func stopPayloadQueueProcessor() {
	close(payloadQueueDone)
}

func analyzePayload(payload []byte) []AnalyzedPayload {
	payloadLength := len(payload)

	if payloadLength == 0 {
		return nil
	}

	var analyzed []AnalyzedPayload
	consumed := 0

	for consumed < payloadLength {
		relStart := bytes.Index(payload[consumed:], startDelimiter)
		if relStart < 0 {
			break
		}
		startIdx := consumed + relStart

		scanFrom := startIdx + len(startDelimiter)
		if scanFrom > payloadLength {
			break
		}
		relEnd := bytes.Index(payload[scanFrom:], endDelimiter)
		if relEnd < 0 {
			break
		}
		endIdx := scanFrom + relEnd

		for segStart := scanFrom; ; {
			metaEnd := segStart + segmentMetadataLength
			if metaEnd > endIdx {
				break
			}

			dataType := int(binary.LittleEndian.Uint32(payload[segStart : segStart+4]))
			dataLength := int(binary.LittleEndian.Uint32(payload[segStart+4 : segStart+8]))
			dataEncoding := payload[segStart+8]

			if dataType == 0 {
				break
			}

			segStart = metaEnd + dataLength

			if segStart > endIdx {
				break
			}

			if dataEncoding != 0 {
				// TODO Brotli 압축 파싱
				continue
			}

			analyzed = append(analyzed, AnalyzedPayload{
				Type:    dataType,
				Content: payload[metaEnd:segStart],
			})
		}

		consumed = endIdx + len(endDelimiter)
	}

	return analyzed
}

func analyzePayloads(payloads []Payload) {
	for _, payload := range payloads {
		datas := analyzePayload(payload.Data)
		var attacks []AttackData
		var hps []HPData

		for _, data := range datas {
			switch data.Type {
			case attackDataType:
				parsed, err := parseAttack(data.Content)
				if err != nil {
					log.Printf("parseAttack error: %v", err)
				}

				if parsed.Key2 != 0 {
					log.Printf("parsed: %v, %v", parsed.Key1, parsed.Key2)
				}

				attacks = append(attacks, parsed)

			case hpDataType:
				//			log.Printf("hp")
				hp, err := parseHP(data.Content)
				if err != nil {
					log.Printf("parseHP error: %v", err)
				}

				if hp.Damage > 0 {
					hps = append(hps, hp)
				}

			case actionDataType:
				parsed, err := parseAction(data.Content)
				if err != nil {
					log.Printf("parseAction error: %v", err)
				}

				saveAction(parsed)
			case selfDamageDataType1, selfDamageDataType2:
				parseSelfDamage(data.Content)
			case itemDataType1, itemDataType2:
				parseItem(data.Content)
			}
			/*
				if len(hps) != len(attacks) {
					log.Printf("attackCount: %d, hpCount: %d", len(attacks), len(hps))
					log.Printf("attacks: %v", attacks)
					log.Printf("hps: %v", hps)
				}
			*/
		}
	}
}

// SaveUsersToJSON saves the users data to a JSON file
func SaveUsersToJSON() {
	for k, v := range skills {
		if len(v) > 1 {
			log.Printf("skills[%d]: %v", k, v)
		}
	}

	// Create logs directory if it doesn't exist
	logsDir := "logs"
	if err := os.MkdirAll(logsDir, 0755); err != nil {
		log.Printf("Failed to create logs directory: %v", err)
		return
	}

	// Generate filename with current date
	filename := filepath.Join(logsDir, "users_data.json")

	// Convert users map to JSON
	jsonData, err := json.MarshalIndent(users, "", "  ")
	if err != nil {
		log.Printf("Failed to marshal users data to JSON: %v", err)
		return
	}

	log.Printf("JSON data length: %d bytes", len(jsonData))

	// Write to file
	if err := os.WriteFile(filename, jsonData, 0644); err != nil {
		log.Printf("Failed to write users data to file: %v", err)
		return
	}

	log.Printf("Users data saved to %s", filename)
}
