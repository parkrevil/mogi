package packet

import (
	"encoding/binary"
	"fmt"
	"strings"
)

type ActionData struct {
	UserID uint32
	Skill  string
	Key1   uint32
}

const actionDataMinLength = 12

func parseAction(data []byte) (ActionData, error) {
	if len(data) < actionDataMinLength {
		return ActionData{}, fmt.Errorf("action packet too short: %d bytes, need at least %d", len(data), actionDataMinLength)
	}

	userID := binary.LittleEndian.Uint32(data[0:4])
	skillLen := binary.LittleEndian.Uint32(data[8:12])
	skill := cleanString(data[12 : 12+skillLen])
	key1 := binary.LittleEndian.Uint32(data[12+skillLen+8 : 12+skillLen+12])

	return ActionData{
		UserID: userID,
		Skill:  skill,
		Key1:   key1,
	}, nil
}

func cleanString(data []byte) string {
	if len(data) == 0 {
		return ""
	}

	writeIdx := 0
	for readIdx := 0; readIdx < len(data); readIdx++ {
		if data[readIdx] != 0 {
			data[writeIdx] = data[readIdx]
			writeIdx++
		}
	}

	return strings.TrimSpace(string(data[:writeIdx]))
}
