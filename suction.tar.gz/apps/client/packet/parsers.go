package packet

func parseSelfDamage(data []byte) interface{} {
	// println("parseSelfDamage: ", data)
	return nil
}

func parseItem(data []byte) interface{} {
	// println("parseItem: ", data)
	return nil
}
