package packet

import (
	"strings"
)

type Class uint16

const (
	ClassUnknown        Class        = iota + 0   // 알 수 없음
	ClassExpertWarrior               = iota + 100 // 전사
	ClassGreatsword                               // 대검
	ClassSwordmaster                              // 검술
	ClassHighArcher     = iota + 200              // 궁수
	ClassArbalist                                 // 석궁
	ClassLongbowman                               // 장궁
	ClassHighMage       = iota + 300              // 법사
	ClassFireMage                                 // 화법
	ClassIceMage                                  // 빙결
	ClassLightningMage                            // 전격
	ClassHealer         = iota + 400              // 힐러
	ClassMonk                                     // 수도
	ClassPriest                                   // 사제
	ClassBard           = iota + 500              // 음유
	ClassBattleMusician                           // 악사
	ClassDancer                                   // 댄서
	ClassHighThief      = iota + 600              // 도적
	ClassFighter                                  // 격가
	ClassDualBlades                               // 듀블
)

type Skill struct {
	Key1      uint32 `json:"key1"`
	SkillName string `json:"skill_name"`
}

type User struct {
	ID     uint32  `json:"id"`
	Class  Class   `json:"class"`
	Skills []Skill `json:"skills"`
}

var users = map[uint32]User{}
var hp HPData
var skills = make(map[uint32][]string)

func getClassAndSkillFromActionSkill(actionSkill string) (Class, string) {
	class := func() Class {
		lowerActionSkill := strings.ToLower(actionSkill)

		switch {
		case strings.HasPrefix(lowerActionSkill, "expertwarrior_"):
			return ClassExpertWarrior
		case strings.HasPrefix(lowerActionSkill, "greatswordwarrior_"):
			return ClassGreatsword
		case strings.HasPrefix(lowerActionSkill, "swordmaster_"):
			return ClassSwordmaster
		case strings.HasPrefix(lowerActionSkill, "higharcher_"):
			return ClassHighArcher
		case strings.HasPrefix(lowerActionSkill, "arbalist_"):
			return ClassArbalist
		case strings.HasPrefix(lowerActionSkill, "longbowman_"):
			return ClassLongbowman
		case strings.HasPrefix(lowerActionSkill, "highmage_"):
			return ClassHighMage
		case strings.HasPrefix(lowerActionSkill, "firemage_"):
			return ClassFireMage
		case strings.HasPrefix(lowerActionSkill, "icemage_"):
			return ClassIceMage
		case strings.HasPrefix(lowerActionSkill, "lightningmage_"):
			return ClassLightningMage
		case strings.HasPrefix(lowerActionSkill, "healer_"):
			return ClassHealer
		case strings.HasPrefix(lowerActionSkill, "monk_"):
			return ClassMonk
		case strings.HasPrefix(lowerActionSkill, "priest_"):
			return ClassPriest
		case strings.HasPrefix(lowerActionSkill, "bard_"):
			return ClassBard
		case strings.HasPrefix(lowerActionSkill, "battlemusician_"):
			return ClassBattleMusician
		case strings.HasPrefix(lowerActionSkill, "dancer_"):
			return ClassDancer
		case strings.HasPrefix(lowerActionSkill, "highthief_"):
			return ClassHighThief
		case strings.HasPrefix(lowerActionSkill, "fighter_"):
			return ClassFighter
		case strings.HasPrefix(lowerActionSkill, "dualblades_"):
			return ClassDualBlades
		default:
			return ClassUnknown
		}
	}()

	skill := actionSkill
	if class != ClassUnknown {
		skill = actionSkill[strings.Index(actionSkill, "_")+1:]
	}

	return class, skill
}

func saveAction(action ActionData) {
	user, ok := users[action.UserID]
	class, skillName := getClassAndSkillFromActionSkill(action.Skill)
	if !ok {
		user = User{
			ID:     action.UserID,
			Class:  class,
			Skills: []Skill{},
		}
	}

	if user.Class == ClassUnknown {
		user.Class = class
	}

	user.Skills = append(user.Skills, Skill{
		Key1:      action.Key1,
		SkillName: skillName,
	})

	users[action.UserID] = user
}

func setHp(hpData HPData) {
	hp = hpData
}

func processAttack(attack AttackData) {
}
